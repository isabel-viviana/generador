<?php

namespace App\Http\Controllers;

use App\Models\{{CLASS_NAME}};
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
{{USE_CLOUDINARY}}
class {{CLASS_NAME}}Controller extends Controller
{
    /**
     * Listar todos los registros.
     */
    public function index(): JsonResponse
    {
        $items = {{INDEX_QUERY}};

        return response()->json([
            'success' => true,
            'message' => 'Lista de {{PLURAL_LOWER}} obtenida correctamente.',
            'data' => $items,
        ], 200);
    }

    /**
     * Crear un nuevo registro.
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
{{STORE_VALIDATION_RULES}}
        ]);
{{CLOUDINARY_STORE_UPLOAD}}
        $item = {{CLASS_NAME}}::create($data);

        return response()->json([
            'success' => true,
            'message' => '{{CLASS_NAME}} creado correctamente.',
            'data' => $item,
        ], 201);
    }

    /**
     * Mostrar un registro específico.
     */
    public function show($id): JsonResponse
    {
        $item = {{SHOW_QUERY}};

        return response()->json([
            'success' => true,
            'data' => $item,
        ], 200);
    }

    /**
     * Actualizar un registro existente.
     */
    public function update(Request $request, $id): JsonResponse
    {
        $item = {{CLASS_NAME}}::findOrFail($id);

        $data = $request->validate([
{{UPDATE_VALIDATION_RULES}}
        ]);
{{CLOUDINARY_UPDATE_UPLOAD}}
        $item->update($data);

        return response()->json([
            'success' => true,
            'message' => '{{CLASS_NAME}} actualizado correctamente.',
            'data' => $item,
        ], 200);
    }

    /**
     * Eliminar un registro.
     */
    public function destroy($id): JsonResponse
    {
        $item = {{CLASS_NAME}}::findOrFail($id);
        $item->delete();

        return response()->json([
            'success' => true,
            'message' => '{{CLASS_NAME}} eliminado correctamente.',
            'data' => null,
        ], 200);
    }
}
