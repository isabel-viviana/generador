<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
{{USE_RELATIONS}}
class {{CLASS_NAME}} extends Model
{
{{TABLE_PROPERTY}}    protected $fillable = [
{{FILLABLE}}
    ];
{{RELATIONS}}
}
