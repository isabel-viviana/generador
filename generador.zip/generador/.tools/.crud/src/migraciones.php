<?php
// Analizador estático de migraciones de Laravel en PHP nativo (solo lectura).

// Comprueba si un nombre de columna coincide con los patrones configurados para imágenes.
function _es_campo_imagen($nombre_columna, $patrones_config)
{
    $nombre = strtolower($nombre_columna);
    foreach ($patrones_config as $patron) {
        $patron = strtolower(trim($patron));
        if (strpos($patron, '*') !== false) {
            $regex = '/^' . str_replace('\*', '.*', preg_quote($patron, '/')) . '$/i';
            if (preg_match($regex, $nombre)) {
                return true;
            }
        } elseif ($nombre === $patron) {
            return true;
        }
    }
    return false;
}

// Extrae el valor literal de una cadena de argumento entre comillas ('texto' o "texto") o null si no es literal.
function _extraer_literal_string($texto)
{
    $texto = trim($texto);
    if (preg_match('/^[\'"](.*)[\'"]$/s', $texto, $m)) {
        return $m[1];
    }
    return null;
}

// Extrae literales separados por comas al nivel exterior de paréntesis, respetando comillas y corchetes.
function _parsear_argumentos_literales($args_str)
{
    $args_str = trim($args_str);
    if ($args_str === '') {
        return [];
    }

    $args = [];
    $actual = '';
    $en_comilla = false;
    $tipo_comilla = '';
    $nivel_corchetes = 0;
    $nivel_parentesis = 0;
    $len = strlen($args_str);

    for ($i = 0; $i < $len; $i++) {
        $ch = $args_str[$i];

        if ($en_comilla) {
            $actual .= $ch;
            if ($ch === $tipo_comilla && ($i === 0 || $args_str[$i - 1] !== '\\')) {
                $en_comilla = false;
            }
            continue;
        }

        if ($ch === '\'' || $ch === '"') {
            $en_comilla = true;
            $tipo_comilla = $ch;
            $actual .= $ch;
            continue;
        }

        if ($ch === '[') {
            $nivel_corchetes++;
        } elseif ($ch === ']') {
            $nivel_corchetes--;
        } elseif ($ch === '(') {
            $nivel_parentesis++;
        } elseif ($ch === ')') {
            $nivel_parentesis--;
        }

        if ($ch === ',' && $nivel_corchetes === 0 && $nivel_parentesis === 0) {
            $args[] = trim($actual);
            $actual = '';
            continue;
        }

        $actual .= $ch;
    }

    if (trim($actual) !== '') {
        $args[] = trim($actual);
    }

    return $args;
}

// Desglosa las llamadas encadenadas ->metodo(...) de una sentencia sin confundir flechas o paréntesis dentro de strings.
function _desglosar_llamadas_encadenadas($sentencia)
{
    $llamadas = [];
    $len = strlen($sentencia);
    $en_comilla = false;
    $tipo_comilla = '';
    $i = 0;

    while ($i < $len) {
        $ch = $sentencia[$i];

        if ($en_comilla) {
            if ($ch === $tipo_comilla && ($i === 0 || $sentencia[$i - 1] !== '\\')) {
                $en_comilla = false;
            }
            $i++;
            continue;
        }

        if ($ch === '\'' || $ch === '"') {
            $en_comilla = true;
            $tipo_comilla = $ch;
            $i++;
            continue;
        }

        // Buscar inicio de llamada '->'
        if ($ch === '-' && ($i + 1 < $len) && $sentencia[$i + 1] === '>') {
            $i += 2;
            // Leer nombre del método
            $nombre_metodo = '';
            while ($i < $len && preg_match('/[a-zA-Z0-9_]/', $sentencia[$i])) {
                $nombre_metodo .= $sentencia[$i];
                $i++;
            }

            if ($nombre_metodo === '') {
                continue;
            }

            // Omitir espacios entre nombre de método y '(' si los hay
            while ($i < $len && ($sentencia[$i] === ' ' || $sentencia[$i] === "\t" || $sentencia[$i] === "\r" || $sentencia[$i] === "\n")) {
                $i++;
            }

            // Si tiene argumentos (...)
            $args_raw = '';
            if ($i < $len && $sentencia[$i] === '(') {
                $nivel = 1;
                $i++;
                $comilla_args = false;
                $t_comilla_args = '';

                while ($i < $len && $nivel > 0) {
                    $c = $sentencia[$i];
                    if ($comilla_args) {
                        $args_raw .= $c;
                        if ($c === $t_comilla_args && ($i === 0 || $sentencia[$i - 1] !== '\\')) {
                            $comilla_args = false;
                        }
                        $i++;
                        continue;
                    }

                    if ($c === '\'' || $c === '"') {
                        $comilla_args = true;
                        $t_comilla_args = $c;
                        $args_raw .= $c;
                        $i++;
                        continue;
                    }

                    if ($c === '(') {
                        $nivel++;
                    } elseif ($c === ')') {
                        $nivel--;
                        if ($nivel === 0) {
                            $i++;
                            break;
                        }
                    }

                    $args_raw .= $c;
                    $i++;
                }
            }

            $llamadas[] = [
                'metodo' => $nombre_metodo,
                'args_raw' => $args_raw,
            ];
            continue;
        }

        $i++;
    }

    return $llamadas;
}

// Analiza una sentencia de definición sobre $table (ej: $table->string('nombre', 100)->nullable();)
function _analizar_sentencia_columna($sentencia, $patrones_imagen, $archivo, $linea_aprox, &$advertencias)
{
    $sentencia = rtrim(trim($sentencia), ';');

    // Desglosar de forma segura respetando comillas y paréntesis
    $llamadas = _desglosar_llamadas_encadenadas($sentencia);
    if (empty($llamadas)) {
        return null;
    }

    $primera_llamada = $llamadas[0];
    $metodo_tipo = $primera_llamada['metodo'];
    $args = _parsear_argumentos_literales($primera_llamada['args_raw']);

    // Tipos soportados
    $tipos_conocidos = [
        'id', 'increments', 'bigIncrements',
        'string', 'char', 'text', 'mediumText', 'longText',
        'integer', 'tinyInteger', 'smallInteger', 'mediumInteger', 'bigInteger',
        'unsignedInteger', 'unsignedTinyInteger', 'unsignedSmallInteger', 'unsignedMediumInteger', 'unsignedBigInteger',
        'decimal', 'float', 'double',
        'boolean',
        'date', 'dateTime', 'dateTimeTz', 'time', 'timeTz', 'timestamp', 'timestampTz',
        'foreignId', 'foreignIdFor',
        'enum', 'json',
        'timestamps', 'timestampsTz',
        'softDeletes', 'softDeletesTz',
        'foreign', 'dropColumn', 'renameColumn'
    ];

    if (!in_array($metodo_tipo, $tipos_conocidos, true)) {
        $advertencias[] = "[$archivo:~L$linea_aprox] Método de columna no reconocido o no soportado: '->$metodo_tipo()'.";
        return null;
    }

    // Casos estructurales sin nombre explícito o con nombres especiales
    if ($metodo_tipo === 'id' || $metodo_tipo === 'increments' || $metodo_tipo === 'bigIncrements') {
        $nombre_col = !empty($args) ? (_extraer_literal_string($args[0]) ?? 'id') : 'id';
        return [
            'tipo_accion' => 'columna',
            'nombre' => $nombre_col,
            'tipo' => 'id',
            'es_pk' => true,
            'nullable' => false,
            'default' => null,
            'unique' => true,
            'es_imagen' => false,
            'fk' => null,
            'opciones' => [],
        ];
    }

    if ($metodo_tipo === 'timestamps' || $metodo_tipo === 'timestampsTz') {
        return [
            'tipo_accion' => 'timestamps',
        ];
    }

    if ($metodo_tipo === 'softDeletes' || $metodo_tipo === 'softDeletesTz') {
        return [
            'tipo_accion' => 'soft_deletes',
        ];
    }

    // Casos de alteración básica con Schema::table
    if ($metodo_tipo === 'dropColumn') {
        $cols_a_borrar = [];
        foreach ($args as $a) {
            $l = _extraer_literal_string($a);
            if ($l !== null) {
                $cols_a_borrar[] = $l;
            } elseif (preg_match('/\[(.*)\]/s', $a, $am)) {
                // Posible array: dropColumn(['a', 'b'])
                $sub = _parsear_argumentos_literales($am[1]);
                foreach ($sub as $s) {
                    $sl = _extraer_literal_string($s);
                    if ($sl !== null) $cols_a_borrar[] = $sl;
                }
            }
        }
        return [
            'tipo_accion' => 'drop_column',
            'columnas' => $cols_a_borrar,
        ];
    }

    if ($metodo_tipo === 'renameColumn') {
        $from = _extraer_literal_string($args[0] ?? '');
        $to = _extraer_literal_string($args[1] ?? '');
        if ($from && $to) {
            return [
                'tipo_accion' => 'rename_column',
                'de' => $from,
                'a' => $to,
            ];
        }
        return null;
    }

    // Caso de definición explícita de foreign key: $table->foreign('categoria_id')->references('id')->on('categorias')
    if ($metodo_tipo === 'foreign') {
        $col_fk = _extraer_literal_string($args[0] ?? '');
        if (!$col_fk) {
            $advertencias[] = "[$archivo:~L$linea_aprox] Expresión dinámica en \$table->foreign(...). No se pudo extraer la columna.";
            return null;
        }

        $ref_col = 'id';
        $ref_tabla = null;
        $on_delete = null;

        for ($i = 1; $i < count($llamadas); $i++) {
            $mod = $llamadas[$i]['metodo'];
            $m_args = _parsear_argumentos_literales($llamadas[$i]['args_raw']);
            if ($mod === 'references') {
                $ref_col = _extraer_literal_string($m_args[0] ?? '') ?? 'id';
            } elseif ($mod === 'on') {
                $ref_tabla = _extraer_literal_string($m_args[0] ?? '');
            } elseif ($mod === 'onDelete') {
                $on_delete = _extraer_literal_string($m_args[0] ?? '') ?? 'cascade';
            } elseif ($mod === 'cascadeOnDelete') {
                $on_delete = 'cascade';
            } elseif ($mod === 'nullOnDelete') {
                $on_delete = 'set null';
            }
        }

        if ($ref_tabla) {
            return [
                'tipo_accion' => 'fk_explicita',
                'columna' => $col_fk,
                'referencia_tabla' => $ref_tabla,
                'referencia_columna' => $ref_col,
                'on_delete' => $on_delete,
            ];
        } else {
            $advertencias[] = "[$archivo:~L$linea_aprox] Clave foránea sobre '$col_fk' sin cláusula ->on('tabla') explícita.";
            return null;
        }
    }

    // Columna normal: el primer argumento es el nombre
    $nombre_col = _extraer_literal_string($args[0] ?? '');
    if ($nombre_col === null) {
        $advertencias[] = "[$archivo:~L$linea_aprox] No se pudo determinar el nombre literal de la columna en '->$metodo_tipo()'. Expresión dinámica u omitida.";
        return null;
    }

    // Parámetros secundarios según tipo
    $opciones_tipo = [];
    if (($metodo_tipo === 'string' || $metodo_tipo === 'char') && isset($args[1])) {
        if (is_numeric($args[1])) {
            $opciones_tipo['longitud'] = (int)$args[1];
        }
    } elseif ($metodo_tipo === 'decimal') {
        $opciones_tipo['precision'] = isset($args[1]) && is_numeric($args[1]) ? (int)$args[1] : 8;
        $opciones_tipo['escala'] = isset($args[2]) && is_numeric($args[2]) ? (int)$args[2] : 2;
    } elseif ($metodo_tipo === 'enum') {
        $valores_enum = [];
        if (isset($args[1]) && preg_match('/\[(.*)\]/s', $args[1], $em)) {
            $subargs = _parsear_argumentos_literales($em[1]);
            foreach ($subargs as $sa) {
                $sv = _extraer_literal_string($sa);
                if ($sv !== null) $valores_enum[] = $sv;
            }
        }
        $opciones_tipo['valores'] = $valores_enum;
    }

    // Procesar modificadores encadenados (independiente del orden)
    $nullable = false;
    $default = null;
    $unique = false;

    // Recolectores temporales para FK
    $es_foreign_id = ($metodo_tipo === 'foreignId');
    $tiene_constrained = false;
    $fk_ref_tabla = null;
    $fk_on_delete = null;

    for ($i = 1; $i < count($llamadas); $i++) {
        $mod = $llamadas[$i]['metodo'];
        $m_args = _parsear_argumentos_literales($llamadas[$i]['args_raw']);

        // 1. Modificador nullable: ->nullable() o ->nullable(true/false)
        if ($mod === 'nullable') {
            if (empty($m_args) || trim($m_args[0]) === '' || strtolower(trim($m_args[0])) === 'true') {
                $nullable = true;
            } elseif (strtolower(trim($m_args[0])) === 'false') {
                $nullable = false;
            } else {
                $nullable = true;
            }
        }

        // 2. Modificador default: valores literales simples vs expresiones dinámicas
        elseif ($mod === 'default') {
            $def_val = $m_args[0] ?? null;
            if ($def_val !== null) {
                $def_val_trimmed = trim($def_val);
                $str_val = _extraer_literal_string($def_val_trimmed);

                if ($str_val !== null) {
                    $default = $str_val;
                } elseif (strtolower($def_val_trimmed) === 'true') {
                    $default = true;
                } elseif (strtolower($def_val_trimmed) === 'false') {
                    $default = false;
                } elseif (strtolower($def_val_trimmed) === 'null') {
                    $default = null;
                } elseif (is_numeric($def_val_trimmed)) {
                    $default = strpos($def_val_trimmed, '.') !== false ? (float)$def_val_trimmed : (int)$def_val_trimmed;
                } else {
                    // Expresión dinámica (ej: now(), DB::raw(...), constantes PHP o funciones)
                    $advertencias[] = "[$archivo:~L$linea_aprox] Expresión dinámica o no literal en ->default('$def_val_trimmed') para la columna '$nombre_col'; se omite valor por defecto.";
                    $default = null;
                }
            }
        }

        // 3. Modificador unique
        elseif ($mod === 'unique') {
            $unique = true;
        }

        // 4. Modificadores de Foreign Key (independiente del orden de llamada)
        elseif ($mod === 'constrained') {
            $tiene_constrained = true;
            if (!empty($m_args)) {
                $fk_ref_tabla = _extraer_literal_string($m_args[0]);
            }
        } elseif ($mod === 'cascadeOnDelete') {
            $fk_on_delete = 'cascade';
        } elseif ($mod === 'nullOnDelete') {
            $fk_on_delete = 'set null';
        } elseif ($mod === 'onDelete') {
            $fk_on_delete = _extraer_literal_string($m_args[0] ?? '') ?? 'cascade';
        }
    }

    // Ensamblar FK si hubo constrained() o es foreignId explícito
    $fk = null;
    if ($tiene_constrained) {
        if (!$fk_ref_tabla) {
            // Inferencia estándar de Laravel: 'categoria_id' -> 'categorias'
            if (preg_match('/^(.*)_id$/', $nombre_col, $fkm)) {
                $fk_ref_tabla = $fkm[1] . 's';
            }
        }

        if ($fk_ref_tabla) {
            $fk = [
                'referencia_tabla' => $fk_ref_tabla,
                'referencia_columna' => 'id',
                'on_delete' => $fk_on_delete,
            ];
        } else {
            $advertencias[] = "[$archivo:~L$linea_aprox] ->constrained() en '$nombre_col' no pudo resolver tabla de destino.";
        }
    } elseif ($es_foreign_id || $metodo_tipo === 'foreignIdFor') {
        if (preg_match('/^(.*)_id$/', $nombre_col, $fkm)) {
            $fk = [
                'referencia_tabla' => $fkm[1] . 's',
                'referencia_columna' => 'id',
                'on_delete' => $fk_on_delete,
            ];
        }
    }

    $es_img = _es_campo_imagen($nombre_col, $patrones_imagen);

    return [
        'tipo_accion' => 'columna',
        'nombre' => $nombre_col,
        'tipo' => $metodo_tipo,
        'opciones' => $opciones_tipo,
        'es_pk' => false,
        'nullable' => $nullable,
        'default' => $default,
        'unique' => $unique,
        'es_imagen' => $es_img,
        'fk' => $fk,
    ];
}

// Analiza el contenido PHP de un archivo de migración tokenizado.
function _analizar_archivo_migracion($ruta_archivo, $patrones_imagen, &$advertencias)
{
    $codigo = @file_get_contents($ruta_archivo);
    if ($codigo === false) {
        $advertencias[] = "No se pudo leer el archivo de migración: $ruta_archivo";
        return [];
    }

    $nombre_archivo = basename($ruta_archivo);
    $tokens = token_get_all($codigo);
    $total_tokens = count($tokens);

    // 1. Localizar el cuerpo del método up()
    $en_up = false;
    $nivel_llaves = 0;
    $nivel_llaves_up = 0;
    $tokens_up = [];

    for ($i = 0; $i < $total_tokens; $i++) {
        $token = $tokens[$i];

        if (is_array($token)) {
            if ($token[0] === T_FUNCTION) {
                $j = $i + 1;
                while ($j < $total_tokens && is_array($tokens[$j]) && ($tokens[$j][0] === T_WHITESPACE || $tokens[$j][0] === T_COMMENT || $tokens[$j][0] === T_DOC_COMMENT)) {
                    $j++;
                }
                if ($j < $total_tokens && is_array($tokens[$j]) && $tokens[$j][0] === T_STRING && strtolower($tokens[$j][1]) === 'up') {
                    $en_up = true;
                    $nivel_llaves_up = $nivel_llaves;
                }
            }
        } else {
            if ($token === '{') {
                $nivel_llaves++;
            } elseif ($token === '}') {
                $nivel_llaves--;
                if ($en_up && $nivel_llaves === $nivel_llaves_up) {
                    $en_up = false;
                    break;
                }
            }
        }

        if ($en_up) {
            $tokens_up[] = $token;
        }
    }

    if (empty($tokens_up)) {
        return [];
    }

    // 2. Extraer bloques Schema::create y Schema::table dentro de up()
    $operaciones = [];
    $total_up = count($tokens_up);

    for ($i = 0; $i < $total_up; $i++) {
        $t = $tokens_up[$i];

        // Buscar T_STRING 'DB' :: statement
        if (is_array($t) && $t[0] === T_STRING && $t[1] === 'DB') {
            $linea = $t[2];
            $advertencias[] = "[$nombre_archivo:~L$linea] Sentencia DB:: detectada en up(); no se interpretará código SQL crudo.";
        }

        // Buscar estructuras dinámicas o bucles fuera o dentro de Schema (foreach, for, while)
        if (is_array($t) && in_array($t[0], [T_FOREACH, T_FOR, T_WHILE], true)) {
            $linea = $t[2];
            $advertencias[] = "[$nombre_archivo:~L$linea] Estructura de control o bucle dinámico detectado ({$t[1]}); se omite para evitar inconsistencias.";
        }

        // Buscar Schema::create o Schema::table
        if (is_array($t) && $t[0] === T_STRING && $t[1] === 'Schema') {
            $j = $i + 1;
            while ($j < $total_up && is_array($tokens_up[$j]) && ($tokens_up[$j][0] === T_WHITESPACE)) {
                $j++;
            }
            if ($j < $total_up && is_array($tokens_up[$j]) && $tokens_up[$j][0] === T_DOUBLE_COLON) {
                $j++;
                while ($j < $total_up && is_array($tokens_up[$j]) && ($tokens_up[$j][0] === T_WHITESPACE)) {
                    $j++;
                }
                if ($j < $total_up && is_array($tokens_up[$j]) && $tokens_up[$j][0] === T_STRING && in_array(strtolower($tokens_up[$j][1]), ['create', 'table'], true)) {
                    $tipo_schema = strtolower($tokens_up[$j][1]); // 'create' o 'table'
                    $linea_schema = $tokens_up[$j][2];

                    // Avanzar hasta '(' y capturar el primer argumento (nombre de la tabla)
                    $k = $j + 1;
                    while ($k < $total_up && $tokens_up[$k] !== '(') {
                        $k++;
                    }
                    $k++; // después de '('

                    $nombre_tabla = null;
                    while ($k < $total_up && $tokens_up[$k] !== ',') {
                        if (is_array($tokens_up[$k]) && $tokens_up[$k][0] === T_CONSTANT_ENCAPSED_STRING) {
                            $nombre_tabla = _extraer_literal_string($tokens_up[$k][1]);
                        }
                        $k++;
                    }

                    if (!$nombre_tabla) {
                        $advertencias[] = "[$nombre_archivo:~L$linea_schema] Schema::$tipo_schema con nombre de tabla dinámico o no identificable; se omite.";
                        continue;
                    }

                    // Localizar el inicio del closure: function (...) { ... }
                    while ($k < $total_up && $tokens_up[$k] !== '{') {
                        $k++;
                    }
                    if ($k >= $total_up) continue;

                    // Capturar el cuerpo del closure respetando llaves
                    $nivel_closure = 1;
                    $k++; // dentro de {
                    $cuerpo_closure = '';

                    while ($k < $total_up && $nivel_closure > 0) {
                        $tok = $tokens_up[$k];
                        if ($tok === '{') {
                            $nivel_closure++;
                            $cuerpo_closure .= '{';
                        } elseif ($tok === '}') {
                            $nivel_closure--;
                            if ($nivel_closure > 0) {
                                $cuerpo_closure .= '}';
                            }
                        } else {
                            $cuerpo_closure .= is_array($tok) ? $tok[1] : $tok;
                        }
                        $k++;
                    }

                    $operaciones[] = [
                        'tipo_schema' => $tipo_schema,
                        'tabla' => $nombre_tabla,
                        'cuerpo' => $cuerpo_closure,
                        'archivo' => $nombre_archivo,
                        'linea' => $linea_schema,
                    ];

                    $i = $k;
                }
            }
        }
    }

    return $operaciones;
}

// Analiza todas las migraciones contenidas en Backend/database/migrations de forma acumulativa y determinista.
function analizar_migraciones($ruta_backend, $config = [])
{
    $advertencias = [];
    $tablas = [];

    $ruta_migrations = rtrim($ruta_backend, '\\/') . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'migrations';

    if (!is_dir($ruta_migrations)) {
        $advertencias[] = "No se encontró el directorio de migraciones: $ruta_migrations";
        return [
            'tablas' => [],
            'advertencias' => $advertencias,
        ];
    }

    // 1. Obtener archivos .php de migraciones y ordenarlos por nombre de archivo
    $archivos = glob($ruta_migrations . DIRECTORY_SEPARATOR . '*.php');
    if (!$archivos) {
        $archivos = [];
    }
    sort($archivos, SORT_STRING);

    $patrones_imagen = $config['campos_imagen'] ?? [
        'foto', 'imagen', 'image', 'photo', 'avatar', 'logo', 'portada', 'banner', 'miniatura',
        'imagen_*', '*_imagen', 'foto_*', '*_foto', 'img_*',
    ];

    // 2. Extraer operaciones de cada archivo en orden
    $todas_operaciones = [];
    foreach ($archivos as $archivo) {
        $ops = _analizar_archivo_migracion($archivo, $patrones_imagen, $advertencias);
        foreach ($ops as $op) {
            $todas_operaciones[] = $op;
        }
    }

    // 3. Procesar las operaciones acumulativas para construir el esquema más reciente
    foreach ($todas_operaciones as $op) {
        $tabla = $op['tabla'];
        $tipo_schema = $op['tipo_schema'];
        $archivo_origen = $op['archivo'];
        $linea_op = $op['linea'];

        if ($tipo_schema === 'create') {
            if (!isset($tablas[$tabla])) {
                $tablas[$tabla] = [
                    'nombre' => $tabla,
                    'columnas' => [],
                    'timestamps' => false,
                    'soft_deletes' => false,
                    'fks' => [],
                    'es_pivote' => false,
                    'archivos_origen' => [],
                ];
            }
        } elseif ($tipo_schema === 'table') {
            if (!isset($tablas[$tabla])) {
                $tablas[$tabla] = [
                    'nombre' => $tabla,
                    'columnas' => [],
                    'timestamps' => false,
                    'soft_deletes' => false,
                    'fks' => [],
                    'es_pivote' => false,
                    'archivos_origen' => [],
                ];
                $advertencias[] = "[$archivo_origen:~L$linea_op] Schema::table modifica la tabla '$tabla' que no fue creada previamente en las migraciones analizadas.";
            }
        }

        if (!in_array($archivo_origen, $tablas[$tabla]['archivos_origen'], true)) {
            $tablas[$tabla]['archivos_origen'][] = $archivo_origen;
        }

        // Dividir el cuerpo del closure en sentencias separadas por ';'
        $sentencias = [];
        $actual = '';
        $en_comilla = false;
        $tipo_comilla = '';
        $cuerpo = $op['cuerpo'];
        $len = strlen($cuerpo);

        for ($idx = 0; $idx < $len; $idx++) {
            $ch = $cuerpo[$idx];
            if ($en_comilla) {
                $actual .= $ch;
                if ($ch === $tipo_comilla && ($idx === 0 || $cuerpo[$idx - 1] !== '\\')) {
                    $en_comilla = false;
                }
                continue;
            }

            if ($ch === '\'' || $ch === '"') {
                $en_comilla = true;
                $tipo_comilla = $ch;
                $actual .= $ch;
                continue;
            }

            if ($ch === ';') {
                $trimmed = trim($actual);
                if ($trimmed !== '') {
                    $sentencias[] = $trimmed;
                }
                $actual = '';
                continue;
            }

            $actual .= $ch;
        }

        if (trim($actual) !== '') {
            $sentencias[] = trim($actual);
        }

        // Analizar cada sentencia
        foreach ($sentencias as $sent) {
            if (preg_match('/(for|foreach|while|if)\s*\(/i', $sent)) {
                $advertencias[] = "[$archivo_origen:~L$linea_op] Estructura de control o lógica dinámica detectada ('$sent'); se omite para evitar inconsistencias.";
                continue;
            }

            $res = _analizar_sentencia_columna($sent, $patrones_imagen, $archivo_origen, $linea_op, $advertencias);
            if ($res === null) {
                continue;
            }

            $tipo_accion = $res['tipo_accion'] ?? '';

            if ($tipo_accion === 'columna') {
                $col_nom = $res['nombre'];
                $tablas[$tabla]['columnas'][$col_nom] = [
                    'nombre' => $col_nom,
                    'tipo' => $res['tipo'],
                    'es_pk' => $res['es_pk'],
                    'nullable' => $res['nullable'],
                    'default' => $res['default'],
                    'unique' => $res['unique'],
                    'es_imagen' => $res['es_imagen'],
                    'fk' => $res['fk'],
                    'opciones' => $res['opciones'] ?? [],
                ];

                // Si definió una FK asociada
                if (!empty($res['fk'])) {
                    // Evitar duplicar en la lista fks
                    $ya_existe_fk = false;
                    foreach ($tablas[$tabla]['fks'] as $existente) {
                        if ($existente['columna'] === $col_nom) {
                            $ya_existe_fk = true;
                            break;
                        }
                    }
                    if (!$ya_existe_fk) {
                        $tablas[$tabla]['fks'][] = array_merge(['columna' => $col_nom], $res['fk']);
                    }
                }
            } elseif ($tipo_accion === 'timestamps') {
                $tablas[$tabla]['timestamps'] = true;
                $tablas[$tabla]['columnas']['created_at'] = [
                    'nombre' => 'created_at',
                    'tipo' => 'timestamp',
                    'es_pk' => false,
                    'nullable' => true,
                    'default' => null,
                    'unique' => false,
                    'es_imagen' => false,
                    'fk' => null,
                    'opciones' => [],
                ];
                $tablas[$tabla]['columnas']['updated_at'] = [
                    'nombre' => 'updated_at',
                    'tipo' => 'timestamp',
                    'es_pk' => false,
                    'nullable' => true,
                    'default' => null,
                    'unique' => false,
                    'es_imagen' => false,
                    'fk' => null,
                    'opciones' => [],
                ];
            } elseif ($tipo_accion === 'soft_deletes') {
                $tablas[$tabla]['soft_deletes'] = true;
                $tablas[$tabla]['columnas']['deleted_at'] = [
                    'nombre' => 'deleted_at',
                    'tipo' => 'timestamp',
                    'es_pk' => false,
                    'nullable' => true,
                    'default' => null,
                    'unique' => false,
                    'es_imagen' => false,
                    'fk' => null,
                    'opciones' => [],
                ];
            } elseif ($tipo_accion === 'drop_column') {
                foreach ($res['columnas'] as $cdel) {
                    unset($tablas[$tabla]['columnas'][$cdel]);
                    // Si se elimina una columna que era FK, removerla también de la lista de FKs
                    foreach ($tablas[$tabla]['fks'] as $fk_idx => $fk_item) {
                        if ($fk_item['columna'] === $cdel) {
                            unset($tablas[$tabla]['fks'][$fk_idx]);
                        }
                    }
                    $tablas[$tabla]['fks'] = array_values($tablas[$tabla]['fks']);
                }
            } elseif ($tipo_accion === 'rename_column') {
                $de = $res['de'];
                $a = $res['a'];
                if (isset($tablas[$tabla]['columnas'][$de])) {
                    $col_info = $tablas[$tabla]['columnas'][$de];
                    $col_info['nombre'] = $a;
                    $col_info['es_imagen'] = _es_campo_imagen($a, $patrones_imagen);
                    unset($tablas[$tabla]['columnas'][$de]);
                    $tablas[$tabla]['columnas'][$a] = $col_info;

                    // Actualizar referencia en la lista de FKs
                    foreach ($tablas[$tabla]['fks'] as &$fk_item) {
                        if ($fk_item['columna'] === $de) {
                            $fk_item['columna'] = $a;
                        }
                    }
                    unset($fk_item);
                }
            } elseif ($tipo_accion === 'fk_explicita') {
                $col_fk = $res['columna'];
                $nueva_fk = [
                    'columna' => $col_fk,
                    'referencia_tabla' => $res['referencia_tabla'],
                    'referencia_columna' => $res['referencia_columna'],
                    'on_delete' => $res['on_delete'],
                ];

                // Actualizar o agregar a la lista de fks
                $encontrado = false;
                foreach ($tablas[$tabla]['fks'] as &$fk_item) {
                    if ($fk_item['columna'] === $col_fk) {
                        $fk_item = $nueva_fk;
                        $encontrado = true;
                        break;
                    }
                }
                unset($fk_item);

                if (!$encontrado) {
                    $tablas[$tabla]['fks'][] = $nueva_fk;
                }

                if (isset($tablas[$tabla]['columnas'][$col_fk])) {
                    $tablas[$tabla]['columnas'][$col_fk]['fk'] = [
                        'referencia_tabla' => $res['referencia_tabla'],
                        'referencia_columna' => $res['referencia_columna'],
                        'on_delete' => $res['on_delete'],
                    ];
                }
            }
        }
    }

    // 4. Detección conservadora de tablas pivote:
    // Para considerarse pivote con seguridad:
    // A) Posee exactamente 2 claves foráneas (FKs).
    // B) No posee ninguna columna sustancial de datos (solo se permiten opcionalmente: id, created_at, updated_at).
    // C) El nombre de la tabla sigue convencionalmente la combinación singular o plural de dos tablas, o contiene un guion bajo.
    // D) Si no se cumplen estas condiciones claras, es_pivote permanece false.
    foreach ($tablas as $nom_tbl => &$tbl_info) {
        $conteo_fks = count($tbl_info['fks']);

        if ($conteo_fks !== 2) {
            $tbl_info['es_pivote'] = false;
            continue;
        }

        $cols_sustanciales = [];
        foreach ($tbl_info['columnas'] as $c_nom => $c_def) {
            if ($c_def['es_pk'] || in_array($c_nom, ['created_at', 'updated_at', 'deleted_at'], true)) {
                continue;
            }
            if ($c_def['fk'] !== null) {
                continue;
            }
            $cols_sustanciales[] = $c_nom;
        }

        // Si tiene columnas adicionales con datos de negocio, NO es un pivote puro (es una entidad puente con datos propios)
        if (count($cols_sustanciales) > 0) {
            $tbl_info['es_pivote'] = false;
            continue;
        }

        // Verificar señal morfológica conservadora: nombre compuesto con guion bajo (ej: categoria_producto o rol_usuario)
        if (strpos($nom_tbl, '_') !== false) {
            $tbl_info['es_pivote'] = true;
        } else {
            $tbl_info['es_pivote'] = false;
        }
    }
    unset($tbl_info);

    return [
        'tablas' => $tablas,
        'advertencias' => $advertencias,
    ];
}
