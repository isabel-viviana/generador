<?php
// Generador Backend: Modelos Eloquent, Controladores API CRUD, Rutas, Cloudinary y Configuración Laravel.

if (!defined('CRUD_DIR')) {
    define('CRUD_DIR', dirname(__DIR__));
}

require_once CRUD_DIR . '/src/util.php';
require_once CRUD_DIR . '/src/migraciones.php';

// Determina si una tabla es elegible para generación CRUD.
function es_tabla_elegible($nombre_tabla, $tabla_info, $config)
{
    $excluidas = $config['tablas_excluidas'] ?? [
        'users', 'migrations', 'password_reset_tokens', 'password_resets',
        'sessions', 'cache', 'cache_locks', 'jobs', 'job_batches',
        'failed_jobs', 'personal_access_tokens'
    ];

    if (in_array($nombre_tabla, $excluidas, true)) {
        return false;
    }

    // Si es pivote puro sin clave primaria propia (id), no puede ser un modelo CRUD independiente
    $tiene_pk = false;
    foreach ($tabla_info['columnas'] as $c) {
        if (!empty($c['es_pk'])) {
            $tiene_pk = true;
            break;
        }
    }
    if (!empty($tabla_info['es_pivote']) && !$tiene_pk) {
        return false;
    }

    // Validar que el nombre de tabla y la clase resultante sean identificadores PHP válidos
    $clase = nombre_clase($nombre_tabla, $config);
    if (!preg_match('/^[a-zA-Z_\x80-\xff][a-zA-Z0-9_\x80-\xff]*$/', $clase)) {
        return false;
    }

    $palabras_reservadas = [
        'class', 'interface', 'trait', 'enum', 'function', 'fn', 'namespace',
        'self', 'static', 'parent', 'readonly', 'void', 'never', 'null', 'true', 'false', 'match'
    ];
    if (in_array(strtolower($clase), $palabras_reservadas, true)) {
        return false;
    }

    return true;
}

// Infiere la regla de validación de Laravel para una columna analizada.
function _inferir_regla_validacion($col_nom, $col_info)
{
    $tipo = $col_info['tipo'] ?? 'string';
    $nullable = !empty($col_info['nullable']);
    $default = $col_info['default'] ?? null;
    $unique = !empty($col_info['unique']);
    $es_imagen = !empty($col_info['es_imagen']);
    $reglas = [];

    // 1. Presencia
    if ($nullable) {
        $reglas[] = 'nullable';
    } elseif ($default !== null) {
        $reglas[] = 'sometimes';
    } else {
        $reglas[] = 'required';
    }

    // 2. Si es campo de imagen
    if ($es_imagen) {
        $reglas[] = 'image';
        $reglas[] = 'mimes:jpeg,png,jpg,webp,gif';
        $reglas[] = 'max:5120'; // 5MB
        return [
            'base' => $reglas,
            'unique' => $unique,
            'es_imagen' => true,
        ];
    }

    // 3. Tipos estándar de base de datos
    switch ($tipo) {
        case 'integer':
        case 'tinyInteger':
        case 'smallInteger':
        case 'mediumInteger':
        case 'bigInteger':
        case 'unsignedInteger':
        case 'unsignedTinyInteger':
        case 'unsignedSmallInteger':
        case 'unsignedMediumInteger':
        case 'unsignedBigInteger':
            $reglas[] = 'integer';
            break;

        case 'boolean':
            $reglas[] = 'boolean';
            break;

        case 'decimal':
        case 'float':
        case 'double':
            $reglas[] = 'numeric';
            break;

        case 'date':
        case 'dateTime':
        case 'dateTimeTz':
        case 'timestamp':
        case 'timestampTz':
            $reglas[] = 'date';
            break;

        case 'json':
            $reglas[] = 'array';
            break;

        case 'enum':
            if (!empty($col_info['opciones']['valores'])) {
                $valores_limpios = [];
                foreach ($col_info['opciones']['valores'] as $val) {
                    $val_clean = str_replace(["'", '"', "\\", ','], '', (string)$val);
                    if ($val_clean !== '') {
                        $valores_limpios[] = $val_clean;
                    }
                }
                if (!empty($valores_limpios)) {
                    $reglas[] = 'in:' . implode(',', $valores_limpios);
                } else {
                    $reglas[] = 'string';
                }
            } else {
                $reglas[] = 'string';
            }
            break;

        case 'string':
        case 'char':
            $reglas[] = 'string';
            if (strpos(strtolower($col_nom), 'email') !== false || strpos(strtolower($col_nom), 'correo') !== false) {
                $reglas[] = 'email';
            }
            if (!empty($col_info['opciones']['longitud'])) {
                $reglas[] = 'max:' . $col_info['opciones']['longitud'];
            } else {
                $reglas[] = 'max:255';
            }
            break;

        case 'text':
        case 'mediumText':
        case 'longText':
            $reglas[] = 'string';
            break;

        case 'foreignId':
        case 'foreignIdFor':
            $reglas[] = 'integer';
            break;

        default:
            $reglas[] = 'string';
            break;
    }

    return [
        'base' => $reglas,
        'unique' => $unique,
        'es_imagen' => false,
    ];
}

// Analiza y extrae todas las relaciones Eloquent válidas para una tabla (belongsTo, hasMany, belongsToMany).
function obtener_relaciones_modelo($nombre_tabla, $tabla_info, $todas_tablas, $config)
{
    $relaciones = [
        'belongs_to' => [],
        'has_many' => [],
        'belongs_to_many' => [],
    ];
    $metodos_usados = [];
    $excluidas = $config['tablas_excluidas'] ?? [];

    // Helper interno para buscar tabla en $todas_tablas con variantes singular/plural
    $resolver_tabla = function ($nombre) use ($todas_tablas) {
        if (isset($todas_tablas[$nombre])) return $nombre;
        if (isset($todas_tablas[plural($nombre)])) return plural($nombre);
        if (isset($todas_tablas[singular($nombre)])) return singular($nombre);
        $base = preg_replace('/_id$/', '', $nombre);
        if (isset($todas_tablas[$base])) return $base;
        if (isset($todas_tablas[plural($base)])) return plural($base);
        if (isset($todas_tablas[singular($base)])) return singular($base);
        return null;
    };

    // 1. belongsTo: llaves foráneas presentes en esta tabla
    if (!empty($tabla_info['fks'])) {
        foreach ($tabla_info['fks'] as $fk) {
            $col_fk = $fk['columna'];
            $ref_tabla = $fk['referencia_tabla'] ?? '';
            $tabla_resuelta = $resolver_tabla($ref_tabla);

            $clase_rel = null;
            if ($tabla_resuelta && isset($todas_tablas[$tabla_resuelta])) {
                $clase_rel = nombre_clase($tabla_resuelta, $config);
            } elseif ($ref_tabla === 'users' || $col_fk === 'user_id') {
                $clase_rel = 'User';
            } elseif (!empty($ref_tabla)) {
                $clase_rel = nombre_clase($ref_tabla, $config);
            } elseif (preg_match('/^(.*)_id$/', $col_fk, $mfk)) {
                $candidata = $resolver_tabla($mfk[1]);
                if ($candidata) {
                    $clase_rel = nombre_clase($candidata, $config);
                } else {
                    $clase_rel = nombre_clase($mfk[1], $config);
                }
            }

            if (!$clase_rel) {
                continue; // No generar relación si el modelo de destino no existe
            }

            // Nombre del método
            $base_col = preg_replace('/_id$/', '', $col_fk);
            $nombre_metodo = lcfirst(studly($base_col));

            if (isset($metodos_usados[$nombre_metodo])) {
                $nombre_metodo = lcfirst(studly($base_col . '_' . $col_fk));
            }
            $metodos_usados[$nombre_metodo] = true;

            $relaciones['belongs_to'][] = [
                'metodo' => $nombre_metodo,
                'clase' => $clase_rel,
                'columna' => $col_fk,
            ];
        }
    }

    // 2. hasMany: tablas hijas normales que referencian a $nombre_tabla mediante llaves foráneas
    foreach ($todas_tablas as $otra_tabla => $otra_info) {
        if ($otra_tabla === $nombre_tabla || in_array($otra_tabla, $excluidas, true)) {
            continue;
        }

        // Si es una tabla pivote entre dos entidades, se gestiona con belongsToMany
        if (!empty($otra_info['es_pivote'])) {
            continue;
        }

        $fks_hacia_mi = [];
        if (!empty($otra_info['fks'])) {
            foreach ($otra_info['fks'] as $fk_item) {
                $ref = $fk_item['referencia_tabla'] ?? '';
                $apunta_a_mi = ($ref === $nombre_tabla || singular($ref) === singular($nombre_tabla) || $ref === singular($nombre_tabla));
                if (!$apunta_a_mi && preg_match('/^(.*)_id$/', $fk_item['columna'], $mfk)) {
                    if ($mfk[1] === singular($nombre_tabla) || $mfk[1] . 's' === $nombre_tabla) {
                        $apunta_a_mi = true;
                    }
                }
                if ($apunta_a_mi) {
                    $fks_hacia_mi[] = $fk_item;
                }
            }
        }

        if (empty($fks_hacia_mi)) {
            continue;
        }

        $clase_hijo = nombre_clase($otra_tabla, $config);

        if (count($fks_hacia_mi) === 1) {
            $fk_u = $fks_hacia_mi[0];
            $nombre_metodo = lcfirst(studly(plural(singular($otra_tabla))));
            if (isset($metodos_usados[$nombre_metodo])) {
                $nombre_metodo .= 'De' . studly($fk_u['columna']);
            }
            $metodos_usados[$nombre_metodo] = true;

            $relaciones['has_many'][] = [
                'metodo' => $nombre_metodo,
                'clase' => $clase_hijo,
                'columna' => $fk_u['columna'],
            ];
        } else {
            // Múltiples llaves foráneas hacia el mismo modelo padre
            foreach ($fks_hacia_mi as $fk_m) {
                $prefijo = preg_replace('/_?' . preg_quote(singular($nombre_tabla), '/') . '_id$/', '', $fk_m['columna']);
                $prefijo = trim($prefijo, '_');
                if ($prefijo !== '') {
                    $nombre_metodo = lcfirst(studly($prefijo . '_' . plural(singular($otra_tabla))));
                } else {
                    $nombre_metodo = lcfirst(studly(plural(singular($otra_tabla)) . '_' . $fk_m['columna']));
                }
                if (isset($metodos_usados[$nombre_metodo])) {
                    $nombre_metodo .= 'Rel';
                }
                $metodos_usados[$nombre_metodo] = true;

                $relaciones['has_many'][] = [
                    'metodo' => $nombre_metodo,
                    'clase' => $clase_hijo,
                    'columna' => $fk_m['columna'],
                ];
            }
        }
    }

    // 3. belongsToMany: tablas pivote que vinculan $nombre_tabla con otra tabla
    foreach ($todas_tablas as $piv_tabla => $piv_info) {
        if ($piv_tabla === $nombre_tabla || in_array($piv_tabla, $excluidas, true)) {
            continue;
        }

        $fks_piv = $piv_info['fks'] ?? [];
        if (count($fks_piv) !== 2) {
            continue;
        }

        $fk_mi = null;
        $fk_otro = null;

        foreach ($fks_piv as $fk_cand) {
            $ref = $fk_cand['referencia_tabla'] ?? '';
            $es_mi = ($ref === $nombre_tabla || singular($ref) === singular($nombre_tabla) || $ref === singular($nombre_tabla));
            if (!$es_mi && preg_match('/^(.*)_id$/', $fk_cand['columna'], $mfk)) {
                if ($mfk[1] === singular($nombre_tabla) || $mfk[1] . 's' === $nombre_tabla) {
                    $es_mi = true;
                }
            }

            if ($es_mi && $fk_mi === null) {
                $fk_mi = $fk_cand;
            } elseif ($fk_otro === null || ($es_mi && $fk_mi !== null)) {
                $fk_otro = $fk_cand;
            }
        }

        if ($fk_mi && $fk_otro) {
            $ref_otro = $fk_otro['referencia_tabla'] ?? '';
            $tabla_otro_resuelta = $resolver_tabla($ref_otro);

            $clase_otro = null;
            if ($tabla_otro_resuelta && isset($todas_tablas[$tabla_otro_resuelta])) {
                $clase_otro = nombre_clase($tabla_otro_resuelta, $config);
            } elseif ($ref_otro === 'users' || $fk_otro['columna'] === 'user_id') {
                $clase_otro = 'User';
            } elseif (preg_match('/^(.*)_id$/', $fk_otro['columna'], $mfkb)) {
                $cand = $resolver_tabla($mfkb[1]);
                if ($cand) {
                    $clase_otro = nombre_clase($cand, $config);
                }
            }

            if (!$clase_otro) {
                continue;
            }

            $nombre_metodo = lcfirst(studly(plural(singular($tabla_otro_resuelta ?? $ref_otro))));
            if (isset($metodos_usados[$nombre_metodo])) {
                $nombre_metodo = lcfirst(studly(plural(singular($tabla_otro_resuelta ?? $ref_otro)) . 'Via' . studly($piv_tabla)));
            }
            $metodos_usados[$nombre_metodo] = true;

            $relaciones['belongs_to_many'][] = [
                'metodo' => $nombre_metodo,
                'clase' => $clase_otro,
                'tabla_pivote' => $piv_tabla,
                'columna_fk_propia' => $fk_mi['columna'],
                'columna_fk_otra' => $fk_otro['columna'],
            ];
        }
    }

    return $relaciones;
}

// Genera el código fuente de un Modelo Eloquent respetando la estructura limpia definida.
function generar_codigo_modelo($nombre_tabla, $tabla_info, $todas_tablas, $config)
{
    $plantilla_path = CRUD_DIR . '/templates/back/model.tpl';
    if (!file_exists($plantilla_path)) {
        throw new RuntimeException("Plantilla no encontrada: $plantilla_path");
    }
    $tpl = file_get_contents($plantilla_path);

    $clase_nombre = nombre_clase($nombre_tabla, $config);

    // 1. Fillable: columnas que no sean pk ni timestamps
    $columnas_fillable = [];
    foreach ($tabla_info['columnas'] as $c_nom => $c_def) {
        if (!empty($c_def['es_pk']) || in_array($c_nom, ['id', 'created_at', 'updated_at', 'deleted_at'], true)) {
            continue;
        }
        $columnas_fillable[] = "        '$c_nom',";
    }
    $fillable_str = implode("\n", $columnas_fillable);

    // 2. Propiedad $table solo si el nombre de tabla es personalizado o no coincide con snake(plural(clase))
    $tabla_esperada_plural = strtolower(snake(plural(singular($clase_nombre))));
    $tabla_property = '';
    if (!empty($config['clases'][$nombre_tabla]) || $nombre_tabla !== $tabla_esperada_plural) {
        $tabla_property = "    protected \$table = '$nombre_tabla';\n\n";
    }

    // 3. Relaciones Eloquent completas
    $relaciones = obtener_relaciones_modelo($nombre_tabla, $tabla_info, $todas_tablas, $config);
    $metodos_relaciones = [];

    $usa_belongs_to = !empty($relaciones['belongs_to']);
    $usa_has_many = !empty($relaciones['has_many']);
    $usa_belongs_to_many = !empty($relaciones['belongs_to_many']);

    // belongsTo
    foreach ($relaciones['belongs_to'] as $rel) {
        $metodos_relaciones[] = <<<PHP
    public function {$rel['metodo']}(): BelongsTo
    {
        return \$this->belongsTo({$rel['clase']}::class, '{$rel['columna']}');
    }
PHP;
    }

    // hasMany
    foreach ($relaciones['has_many'] as $rel) {
        $metodos_relaciones[] = <<<PHP
    public function {$rel['metodo']}(): HasMany
    {
        return \$this->hasMany({$rel['clase']}::class, '{$rel['columna']}');
    }
PHP;
    }

    // belongsToMany
    foreach ($relaciones['belongs_to_many'] as $rel) {
        $metodos_relaciones[] = <<<PHP
    public function {$rel['metodo']}(): BelongsToMany
    {
        return \$this->belongsToMany(
            {$rel['clase']}::class,
            '{$rel['tabla_pivote']}',
            '{$rel['columna_fk_propia']}',
            '{$rel['columna_fk_otra']}'
        );
    }
PHP;
    }

    // Importaciones necesarias de relaciones
    $imports = [];
    if ($usa_belongs_to) {
        $imports[] = "use Illuminate\\Database\\Eloquent\\Relations\\BelongsTo;";
    }
    if ($usa_has_many) {
        $imports[] = "use Illuminate\\Database\\Eloquent\\Relations\\HasMany;";
    }
    if ($usa_belongs_to_many) {
        $imports[] = "use Illuminate\\Database\\Eloquent\\Relations\\BelongsToMany;";
    }

    $use_relations = !empty($imports) ? implode("\n", $imports) . "\n" : "";
    $relations_str = !empty($metodos_relaciones) ? "\n\n" . implode("\n\n", $metodos_relaciones) : "";

    return str_replace(
        ['{{CLASS_NAME}}', '{{TABLE_PROPERTY}}', '{{FILLABLE}}', '{{RELATIONS}}', '{{USE_RELATIONS}}'],
        [$clase_nombre, $tabla_property, $fillable_str, $relations_str, $use_relations],
        $tpl
    );
}

// Genera el código fuente de un Controlador CRUD directamente en App\Http\Controllers.
function generar_codigo_controlador($nombre_tabla, $tabla_info, $todas_tablas, $config)
{
    $plantilla_path = CRUD_DIR . '/templates/back/controller.tpl';
    if (!file_exists($plantilla_path)) {
        throw new RuntimeException("Plantilla no encontrada: $plantilla_path");
    }
    $tpl = file_get_contents($plantilla_path);

    $clase_nombre = nombre_clase($nombre_tabla, $config);
    $plural_lower = strtolower($nombre_tabla);

    // Identificar si la tabla posee campos de imagen
    $campos_imagen = [];
    foreach ($tabla_info['columnas'] as $c_nom => $c_def) {
        if (!empty($c_def['es_imagen'])) {
            $campos_imagen[] = $c_nom;
        }
    }
    $tiene_imagen = !empty($campos_imagen);

    // 1. Reglas de validación para store y update
    $store_rules = [];
    $update_rules = [];

    foreach ($tabla_info['columnas'] as $c_nom => $c_def) {
        if (!empty($c_def['es_pk']) || in_array($c_nom, ['id', 'created_at', 'updated_at', 'deleted_at'], true)) {
            continue;
        }

        $regla_info = _inferir_regla_validacion($c_nom, $c_def);
        $base = $regla_info['base'];

        if ($regla_info['es_imagen']) {
            $cadena_img = implode('|', $base);
            $store_rules[] = "            '$c_nom' => '$cadena_img',";
            // En update la imagen es nullable para no exigir volver a subirla
            $resto = array_diff($base, ['required']);
            $cadena_up = 'nullable|' . implode('|', $resto);
            $update_rules[] = "            '$c_nom' => '$cadena_up',";
        } elseif ($regla_info['unique']) {
            $resto_unique = array_diff($base, ['required']);
            $prefijo = in_array('required', $base, true) ? 'required' : 'nullable';
            $cadena_base = empty($resto_unique) ? $prefijo : $prefijo . '|' . implode('|', $resto_unique);

            $store_rules[] = "            '$c_nom' => '{$cadena_base}|unique:$nombre_tabla,$c_nom',";
            $update_rules[] = "            '$c_nom' => '{$cadena_base}|unique:$nombre_tabla,$c_nom,' . \$id . ',id',";
        } else {
            $cadena = implode('|', $base);
            $store_rules[] = "            '$c_nom' => '$cadena',";
            $update_rules[] = "            '$c_nom' => '$cadena',";
        }
    }

    $store_validation_str = implode("\n", $store_rules);
    $update_validation_str = implode("\n", $update_rules);

    // 2. Relaciones belongsTo para eager loading en index y show
    $relaciones = obtener_relaciones_modelo($nombre_tabla, $tabla_info, $todas_tablas, $config);
    $with_list = [];
    if (!empty($relaciones['belongs_to'])) {
        foreach ($relaciones['belongs_to'] as $rel) {
            $with_list[] = "'{$rel['metodo']}'";
        }
    }

    if (!empty($with_list)) {
        $index_query = "{$clase_nombre}::with([" . implode(', ', $with_list) . "])->get()";
        $show_query = "{$clase_nombre}::with([" . implode(', ', $with_list) . "])->findOrFail(\$id)";
    } else {
        $index_query = "{$clase_nombre}::get()";
        $show_query = "{$clase_nombre}::findOrFail(\$id)";
    }

    // 3. Lógica de Cloudinary para store() y update()
    $use_cloudinary = '';
    $cloudinary_store_upload = '';
    $cloudinary_update_upload = '';

    if ($tiene_imagen) {
        $use_cloudinary = "use App\Support\Cloudinary;\n";

        $store_lines = [];
        $update_lines = [];

        foreach ($campos_imagen as $campo_img) {
            $store_lines[] = "        if (\$request->hasFile('$campo_img')) {\n            \$data['$campo_img'] = Cloudinary::upload(\$request->file('$campo_img'));\n        }";
            $update_lines[] = "        if (\$request->hasFile('$campo_img')) {\n            \$data['$campo_img'] = Cloudinary::upload(\$request->file('$campo_img'));\n        } else {\n            unset(\$data['$campo_img']); // Conserva la imagen existente\n        }";
        }

        $cloudinary_store_upload = "\n" . implode("\n", $store_lines) . "\n";
        $cloudinary_update_upload = "\n" . implode("\n", $update_lines) . "\n";
    }

    return str_replace(
        [
            '{{CLASS_NAME}}',
            '{{PLURAL_LOWER}}',
            '{{STORE_VALIDATION_RULES}}',
            '{{UPDATE_VALIDATION_RULES}}',
            '{{INDEX_QUERY}}',
            '{{SHOW_QUERY}}',
            '{{USE_CLOUDINARY}}',
            '{{CLOUDINARY_STORE_UPLOAD}}',
            '{{CLOUDINARY_UPDATE_UPLOAD}}',
        ],
        [
            $clase_nombre,
            $plural_lower,
            $store_validation_str,
            $update_validation_str,
            $index_query,
            $show_query,
            $use_cloudinary,
            $cloudinary_store_upload,
            $cloudinary_update_upload,
        ],
        $tpl
    );
}

// ------------------------------------------------------------
// Registro de Rutas API y Compatibilidad Laravel 10, 11 y 12
// ------------------------------------------------------------

// Registra el bloque de rutas API en routes/api.php con namespace App\Http\Controllers.
function registrar_rutas_api($ruta_backend, array $controladores_generados)
{
    $ruta_api_php = $ruta_backend . '/routes/api.php';
    $lineas_rutas = [];

    foreach ($controladores_generados as $item) {
        $recurso = strtolower($item['tabla']);
        $clase_ctrl = $item['clase_ctrl'];
        $lineas_rutas[] = "Route::apiResource('$recurso', \\App\\Http\\Controllers\\{$clase_ctrl}::class);";
    }

    $crlf = "\n";
    $marcador_inicio = '// <crud-generator>';
    $marcador_fin = '// </crud-generator>';
    $bloque_nuevo = $marcador_inicio . $crlf . implode($crlf, $lineas_rutas) . $crlf . $marcador_fin;

    if (!file_exists($ruta_api_php)) {
        $contenido_inicial = "<?php\n\nuse Illuminate\\Support\\Facades\\Route;\n\n" . $bloque_nuevo . "\n";
        escribir_archivo_sin_marca($ruta_api_php, $contenido_inicial);
        return 'creado';
    }

    $contenido_actual = file_get_contents($ruta_api_php);

    $tiene_inicio = strpos($contenido_actual, $marcador_inicio) !== false;
    $tiene_fin = strpos($contenido_actual, $marcador_fin) !== false;

    if ($tiene_inicio && $tiene_fin) {
        $patron = '/' . preg_quote($marcador_inicio, '/') . '.*?' . preg_quote($marcador_fin, '/') . '/s';
        $nuevo_contenido = preg_replace($patron, $bloque_nuevo, $contenido_actual, 1);

        if (substr_count($nuevo_contenido, $marcador_inicio) > 1 || substr_count($nuevo_contenido, $marcador_fin) > 1) {
            $nuevo_contenido = preg_replace('/' . preg_quote($marcador_inicio, '/') . '.*?' . preg_quote($marcador_fin, '/') . '/s', '', $nuevo_contenido);
            $nuevo_contenido = rtrim($nuevo_contenido) . "\n\n" . $bloque_nuevo . "\n";
        }

        if ($nuevo_contenido === $contenido_actual) {
            return 'sin_cambios';
        }

        escribir_archivo_sin_marca($ruta_api_php, $nuevo_contenido);
        return 'actualizado';
    } elseif ($tiene_inicio || $tiene_fin) {
        $limpio = str_replace([$marcador_inicio, $marcador_fin], '', $contenido_actual);
        $nuevo_contenido = rtrim($limpio) . "\n\n" . $bloque_nuevo . "\n";
        escribir_archivo_sin_marca($ruta_api_php, $nuevo_contenido);
        return 'actualizado';
    } else {
        $nuevo_contenido = rtrim($contenido_actual) . "\n\n" . $bloque_nuevo . "\n";
        escribir_archivo_sin_marca($ruta_api_php, $nuevo_contenido);
        return 'actualizado';
    }
}

// Configura el registro de routes/api.php en bootstrap/app.php (Laravel 11 y 12) de forma mínima y segura.
function asegurar_registro_api_laravel11($ruta_backend, &$advertencias)
{
    $bootstrap_app = $ruta_backend . '/bootstrap/app.php';
    if (!file_exists($bootstrap_app)) {
        return false;
    }

    $contenido = file_get_contents($bootstrap_app);

    if (preg_match('/api\s*:/', $contenido) || strpos($contenido, 'routes/api.php') !== false) {
        return true;
    }

    if (strpos($contenido, 'Application::configure') === false) {
        return true;
    }

    if (preg_match('/(withRouting\s*\([^)]*web\s*:\s*__DIR__\s*\.\s*\'[^\']+\'[^,)]*)(,?)/s', $contenido, $m)) {
        $coincidencia = $m[0];
        $linea_api = "\n        api: __DIR__.'/../routes/api.php',";
        
        $reemplazo = rtrim($m[1], ',') . ',' . $linea_api;
        $nuevo_contenido = str_replace($coincidencia, $reemplazo, $contenido);

        $temp_test = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'test_boot_' . uniqid() . '.php';
        file_put_contents($temp_test, $nuevo_contenido);
        $lint = @exec("php -l \"$temp_test\"");
        @unlink($temp_test);

        if (strpos($lint, 'No syntax errors') !== false) {
            escribir_archivo_sin_marca($bootstrap_app, $nuevo_contenido);
            return true;
        } else {
            $advertencias[] = "No se pudo actualizar bootstrap/app.php automáticamente debido a riesgo de sintaxis. Registre 'api: __DIR__.\'/../routes/api.php\'' manualmente.";
            return false;
        }
    }

    $advertencias[] = "No se encontró el bloque withRouting() en bootstrap/app.php para registrar routes/api.php automáticamente.";
    return false;
}

// Genera la clase helper App\Support\Cloudinary si hay tablas con imágenes.
function asegurar_helper_cloudinary($ruta_backend)
{
    $tpl_path = CRUD_DIR . '/templates/back/cloudinary.tpl';
    if (!file_exists($tpl_path)) {
        throw new RuntimeException("Plantilla cloudinary.tpl no encontrada.");
    }

    $target_dir = $ruta_backend . '/app/Support';
    carpetas_permitidas(array_merge(carpetas_permitidas(), [$target_dir]));

    $codigo = file_get_contents($tpl_path);
    $ruta_archivo = $target_dir . '/Cloudinary.php';

    return escribir($ruta_archivo, $codigo);
}

// Configura config/services.php agregando la clave 'cloudinary' solo si no existe.
function configurar_services_cloudinary($ruta_backend, &$advertencias)
{
    $services_path = $ruta_backend . '/config/services.php';
    if (!file_exists($services_path)) {
        $advertencias[] = "Archivo config/services.php no encontrado para configurar Cloudinary.";
        return false;
    }

    $contenido = file_get_contents($services_path);

    if (strpos($contenido, "'cloudinary'") !== false || strpos($contenido, '"cloudinary"') !== false) {
        return true;
    }

    $bloque_cloudinary = <<<PHP

    'cloudinary' => [
        'cloud_name' => env('CLOUDINARY_CLOUD_NAME'),
        'api_key' => env('CLOUDINARY_API_KEY'),
        'api_secret' => env('CLOUDINARY_API_SECRET'),
        'folder' => env('CLOUDINARY_FOLDER', 'crud_uploads'),
    ],
PHP;

    $pos_ultimo_corchete = strrpos($contenido, '];');
    if ($pos_ultimo_corchete === false) {
        $advertencias[] = "No se pudo identificar el retorno de arreglo en config/services.php para añadir Cloudinary.";
        return false;
    }

    $nuevo_contenido = substr($contenido, 0, $pos_ultimo_corchete) . $bloque_cloudinary . "\n" . substr($contenido, $pos_ultimo_corchete);

    $temp_test = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'test_serv_' . uniqid() . '.php';
    file_put_contents($temp_test, $nuevo_contenido);
    $lint = @exec("php -l \"$temp_test\"");
    @unlink($temp_test);

    if (strpos($lint, 'No syntax errors') !== false) {
        escribir_archivo_sin_marca($services_path, $nuevo_contenido);
        return true;
    } else {
        $advertencias[] = "No se pudo actualizar config/services.php automáticamente debido a error de sintaxis en inserción.";
        return false;
    }
}

// Configura las variables de entorno en .env sin sobrescribir valores existentes.
function configurar_env_backend($ruta_backend, $nombre_proyecto, $hay_imagenes, &$advertencias)
{
    $env_path = $ruta_backend . '/.env';
    if (!file_exists($env_path)) {
        $advertencias[] = "Archivo .env no encontrado en Backend.";
        return false;
    }

    $contenido = file_get_contents($env_path);
    $crlf = (strpos($contenido, "\r\n") !== false) ? "\r\n" : "\n";
    $cambio = false;

    // APP_URL con dominio local
    $dominio_back = slug($nombre_proyecto) . '-backend.test';
    $url_local = "http://{$dominio_back}:8001";

    if (preg_match('/^APP_URL=(.*)$/m', $contenido, $m)) {
        $valor_actual = trim($m[1], " '\"");
        if ($valor_actual === '' || $valor_actual === 'http://localhost') {
            $contenido = preg_replace('/^APP_URL=.*$/m', "APP_URL={$url_local}", $contenido);
            $cambio = true;
        }
    } else {
        $contenido = rtrim($contenido) . $crlf . "APP_URL={$url_local}" . $crlf;
        $cambio = true;
    }

    // Variables de Cloudinary
    if ($hay_imagenes) {
        $vars_faltantes = [];
        $variables_requeridas = [
            'CLOUDINARY_CLOUD_NAME' => '',
            'CLOUDINARY_API_KEY' => '',
            'CLOUDINARY_API_SECRET' => '',
            'CLOUDINARY_FOLDER' => 'crud_uploads',
        ];

        foreach ($variables_requeridas as $var => $default_val) {
            if (!preg_match('/^' . preg_quote($var, '/') . '=/m', $contenido)) {
                $vars_faltantes[] = "{$var}={$default_val}";
            }
        }

        if (!empty($vars_faltantes)) {
            $bloque_env = $crlf . "# Cloudinary Credentials" . $crlf . implode($crlf, $vars_faltantes) . $crlf;
            $contenido = rtrim($contenido) . $bloque_env;
            $cambio = true;
        }
    }

    if ($cambio) {
        escribir_archivo_sin_marca($env_path, $contenido);
        return true;
    }

    return false;
}

// ------------------------------------------------------------
// Flujo Principal Backend CRUD
// ------------------------------------------------------------

function generar_backend_crud($ruta_backend, $config)
{
    require_once CRUD_DIR . '/src/hosts.php';

    $resumen = [
        'modelos' => [],
        'controladores' => [],
        'omitidas' => [],
        'rutas_api' => null,
        'cloudinary' => false,
        'env_actualizado' => false,
        'hosts' => null,
        'errores' => [],
        'advertencias' => [],
    ];

    // Permitir escritura en Backend directamente en app/Http/Controllers (PROHIBIDO crear Api/)
    carpetas_permitidas([
        $ruta_backend . '/app/Models',
        $ruta_backend . '/app/Http/Controllers',
        $ruta_backend . '/app/Support',
        $ruta_backend . '/routes',
        $ruta_backend . '/config',
        $ruta_backend,
    ]);

    // 1. Analizar migraciones
    $analisis = analizar_migraciones($ruta_backend, $config);
    $tablas = $analisis['tablas'];
    $resumen['advertencias'] = $analisis['advertencias'];

    if (empty($tablas)) {
        $resumen['advertencias'][] = 'No se detectaron tablas en las migraciones de database/migrations.';
        return $resumen;
    }

    $controladores_generados = [];
    $hay_campos_imagen_global = false;

    // 2. Generar Modelos y Controladores por tabla elegible
    foreach ($tablas as $nom_tbl => $tbl_info) {
        if (!es_tabla_elegible($nom_tbl, $tbl_info, $config)) {
            $motivo = !empty($tbl_info['es_pivote']) ? 'tabla pivote' : 'tabla excluida en configuración';
            $resumen['omitidas'][] = "$nom_tbl ($motivo)";
            continue;
        }

        $clase = nombre_clase($nom_tbl, $config);

        // Verificar si la tabla tiene campos de imagen
        foreach ($tbl_info['columnas'] as $c_def) {
            if (!empty($c_def['es_imagen'])) {
                $hay_campos_imagen_global = true;
                break;
            }
        }

        // A. Generar Modelo Eloquent
        try {
            $codigo_modelo = generar_codigo_modelo($nom_tbl, $tbl_info, $tablas, $config);
            $ruta_modelo = $ruta_backend . '/app/Models/' . $clase . '.php';
            $estado_m = escribir($ruta_modelo, $codigo_modelo);
            $resumen['modelos'][] = [
                'clase' => $clase,
                'archivo' => "app/Models/$clase.php",
                'estado' => $estado_m,
            ];
        } catch (Throwable $e) {
            $resumen['errores'][] = "Error generando modelo $clase: " . $e->getMessage();
        }

        // B. Generar Controlador CRUD directamente en app/Http/Controllers/
        try {
            $codigo_ctrl = generar_codigo_controlador($nom_tbl, $tbl_info, $tablas, $config);
            $ruta_ctrl = $ruta_backend . '/app/Http/Controllers/' . $clase . 'Controller.php';
            $estado_c = escribir($ruta_ctrl, $codigo_ctrl);
            $resumen['controladores'][] = [
                'clase' => $clase . 'Controller',
                'archivo' => "app/Http/Controllers/{$clase}Controller.php",
                'estado' => $estado_c,
            ];
            $controladores_generados[] = [
                'tabla' => $nom_tbl,
                'clase_ctrl' => $clase . 'Controller',
            ];
        } catch (Throwable $e) {
            $resumen['errores'][] = "Error generando controlador {$clase}Controller: " . $e->getMessage();
        }
    }

    // 3. Registrar Rutas API en routes/api.php
    if (!empty($controladores_generados)) {
        try {
            $estado_rutas = registrar_rutas_api($ruta_backend, $controladores_generados);
            $resumen['rutas_api'] = $estado_rutas;

            // Compatibilidad Laravel 11 y 12
            asegurar_registro_api_laravel11($ruta_backend, $resumen['advertencias']);
        } catch (Throwable $e) {
            $resumen['errores'][] = "Error al registrar rutas API: " . $e->getMessage();
        }
    }

    // 4. Integrar Cloudinary si existen campos de imagen
    if ($hay_campos_imagen_global) {
        try {
            asegurar_helper_cloudinary($ruta_backend);
            configurar_services_cloudinary($ruta_backend, $resumen['advertencias']);
            $resumen['cloudinary'] = true;
        } catch (Throwable $e) {
            $resumen['errores'][] = "Error al configurar Cloudinary: " . $e->getMessage();
        }
    }

    // 5. Configurar .env de Backend
    $nom_proy = nombre_proyecto($config);
    try {
        $env_ok = configurar_env_backend($ruta_backend, $nom_proy, $hay_campos_imagen_global, $resumen['advertencias']);
        $resumen['env_actualizado'] = $env_ok;
    } catch (Throwable $e) {
        $resumen['advertencias'][] = "No se pudo actualizar .env: " . $e->getMessage();
    }

    // 6. Configurar Dominio Local en Hosts de Windows
    try {
        $resumen_hosts = configurar_hosts_local($nom_proy);
        $resumen['hosts'] = $resumen_hosts;
        if (!$resumen_hosts['exito'] && $resumen_hosts['estado'] === 'requiere_admin') {
            $resumen['advertencias'][] = "Hosts: agregue manualmente la siguiente línea a C:\\Windows\\System32\\drivers\\etc\\hosts:\n        " . implode("\n        ", $resumen_hosts['lineas_manuales']);
        }
    } catch (Throwable $e) {
        $resumen['advertencias'][] = "Error al verificar hosts: " . $e->getMessage();
    }

    return $resumen;
}
